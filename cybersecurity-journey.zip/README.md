# 🛡️ Cybersecurity Journey

This is my 4-month roadmap to become a penetration tester and bug bounty hunter.