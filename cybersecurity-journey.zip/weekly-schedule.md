# 🛡️ 4-Month Pentesting & Bug Bounty Weekly Schedule

## Week Template

| Day       | Focus Area                    | Hours | Tasks |
|-----------|-------------------------------|-------|-------|
| Monday    | Recon + Enumeration           | 6–8   | Nmap, ffuf, httpx, subdomain discovery |
| Tuesday   | Web Exploitation (OWASP)      | 6–8   | XSS, SQLi, IDOR, CSRF labs |
| Wednesday | Bug Bounty Recon Practice     | 6–7   | HackerOne scopes, writeup analysis |
| Thursday  | Privilege Escalation          | 6–8   | THM/HTB boxes, linpeas, winpeas |
| Friday    | Report Writing + Tool Building| 4–6   | Create scripts, write reports |
| Saturday  | Full Box Simulation / CTF     | 6–9   | End-to-end attack simulation |
| Sunday    | Passive Review / Planning     | 1–3   | Watch videos, review notes |

## Goals:
- Build real-world recon & exploit skills
- Practice report writing & note-taking
- Become comfortable with tools like Nmap, Burp, ffuf, Subfinder
